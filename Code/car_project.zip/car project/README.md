Car game created using object oriented techniques in Python

Car Class
    Instances will be able to turn the car and drive forward

    Attributes:
    - x: an x coordinate 
    - y: a y coordinate
    - heading: a direction the car will drive in degrees



Running the Program:
    - python3 car.py
        Returns location and heading
    - python3 driving_range.py
        Play car game
        Red car: use arrows
        Blue car: use 'a', 's', 'd', 'w' keys